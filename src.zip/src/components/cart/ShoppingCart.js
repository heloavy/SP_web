import { useState } from 'react';
import styled from 'styled-components';
import { 
  Close, 
  Add, 
  Remove, 
  ShoppingCart as CartIcon 
} from '@mui/icons-material';

const CartContainer = styled.div`
  position: fixed;
  top: 0;
  right: ${props => props.isOpen ? '0' : '-400px'};
  width: 400px;
  height: 100vh;
  background: white;
  box-shadow: -2px 0 5px rgba(0,0,0,0.1);
  transition: right 0.3s ease;
  z-index: 1000;

  @media (max-width: 480px) {
    width: 100%;
  }
`;

const CartHeader = styled.div`
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 1rem;
  border-bottom: 1px solid ${props => props.theme.colors.grey};
`;

const CartItems = styled.div`
  height: calc(100vh - 200px);
  overflow-y: auto;
  padding: 1rem;
`;

const CartItem = styled.div`
  display: grid;
  grid-template-columns: 80px 1fr auto;
  gap: 1rem;
  padding: 1rem;
  border-bottom: 1px solid ${props => props.theme.colors.grey};
`;

const ItemImage = styled.img`
  width: 80px;
  height: 100px;
  object-fit: cover;
  border-radius: 4px;
`;

const ItemDetails = styled.div`
  display: flex;
  flex-direction: column;
  gap: 0.5rem;
`;

const QuantityControl = styled.div`
  display: flex;
  align-items: center;
  gap: 0.5rem;
`;

const QuantityButton = styled.button`
  background: none;
  border: 1px solid ${props => props.theme.colors.grey};
  border-radius: 50%;
  width: 24px;
  height: 24px;
  display: flex;
  align-items: center;
  justify-content: center;
  cursor: pointer;

  &:hover {
    background: ${props => props.theme.colors.grey};
  }
`;

const CartFooter = styled.div`
  position: absolute;
  bottom: 0;
  width: 100%;
  padding: 1rem;
  border-top: 1px solid ${props => props.theme.colors.grey};
  background: white;
`;

const CheckoutButton = styled.button`
  width: 100%;
  padding: 1rem;
  background: ${props => props.theme.colors.primary};
  color: white;
  border: none;
  border-radius: 4px;
  cursor: pointer;

  &:hover {
    background: ${props => props.theme.colors.accent};
  }
`;

function ShoppingCart({ isOpen, onClose }) {
  const [cartItems, setCartItems] = useState([
    {
      id: 1,
      title: "Mathematics Textbook - Grade 1",
      price: 29.99,
      quantity: 1,
      image: "/book1.jpg"
    },
    {
      id: 2,
      title: "Science Workbook - Grade 2",
      price: 24.99,
      quantity: 1,
      image: "/book2.jpg"
    }
  ]);

  const updateQuantity = (id, change) => {
    setCartItems(items =>
      items.map(item =>
        item.id === id
          ? { ...item, quantity: Math.max(1, item.quantity + change) }
          : item
      )
    );
  };

  const removeItem = (id) => {
    setCartItems(items => items.filter(item => item.id !== id));
  };

  const total = cartItems.reduce(
    (sum, item) => sum + item.price * item.quantity,
    0
  );

  return (
    <CartContainer isOpen={isOpen}>
      <CartHeader>
        <h2>Your Cart</h2>
        <Close onClick={onClose} style={{ cursor: 'pointer' }} />
      </CartHeader>

      <CartItems>
        {cartItems.map(item => (
          <CartItem key={item.id}>
            <ItemImage src={item.image} alt={item.title} />
            <ItemDetails>
              <h4>{item.title}</h4>
              <p>${item.price}</p>
              <QuantityControl>
                <QuantityButton onClick={() => updateQuantity(item.id, -1)}>
                  <Remove />
                </QuantityButton>
                <span>{item.quantity}</span>
                <QuantityButton onClick={() => updateQuantity(item.id, 1)}>
                  <Add />
                </QuantityButton>
              </QuantityControl>
            </ItemDetails>
            <Close 
              onClick={() => removeItem(item.id)} 
              style={{ cursor: 'pointer' }} 
            />
          </CartItem>
        ))}
      </CartItems>

      <CartFooter>
        <p>Total: ${total.toFixed(2)}</p>
        <CheckoutButton>Proceed to Checkout</CheckoutButton>
      </CartFooter>
    </CartContainer>
  );
}

export default ShoppingCart; 