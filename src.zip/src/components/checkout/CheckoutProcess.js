import { useState } from 'react';
import styled from 'styled-components';
import { 
  ShoppingCart, 
  Person, 
  LocalShipping, 
  Payment,
  Check 
} from '@mui/icons-material';

const CheckoutContainer = styled.div`
  max-width: 1200px;
  margin: 0 auto;
  padding: 2rem;
`;

const Steps = styled.div`
  display: flex;
  justify-content: space-between;
  margin-bottom: 3rem;
  position: relative;

  &::after {
    content: '';
    position: absolute;
    top: 25px;
    left: 0;
    right: 0;
    height: 2px;
    background: ${props => props.theme.colors.grey};
    z-index: 0;
  }
`;

const Step = styled.div`
  display: flex;
  flex-direction: column;
  align-items: center;
  position: relative;
  z-index: 1;
`;

const StepIcon = styled.div`
  width: 50px;
  height: 50px;
  border-radius: 50%;
  background: ${props => props.active ? props.theme.colors.primary : 'white'};
  color: ${props => props.active ? 'white' : props.theme.colors.text};
  border: 2px solid ${props => props.active ? props.theme.colors.primary : props.theme.colors.grey};
  display: flex;
  align-items: center;
  justify-content: center;
  margin-bottom: 0.5rem;
`;

const StepLabel = styled.span`
  color: ${props => props.active ? props.theme.colors.primary : props.theme.colors.text};
  font-weight: ${props => props.active ? 'bold' : 'normal'};
`;

const Form = styled.form`
  max-width: 600px;
  margin: 0 auto;
`;

const FormGroup = styled.div`
  margin-bottom: 1.5rem;
`;

const Label = styled.label`
  display: block;
  margin-bottom: 0.5rem;
  font-weight: bold;
`;

const Input = styled.input`
  width: 100%;
  padding: 0.8rem;
  border: 1px solid ${props => props.theme.colors.grey};
  border-radius: 4px;

  &:focus {
    outline: none;
    border-color: ${props => props.theme.colors.primary};
  }
`;

const Button = styled.button`
  background: ${props => props.theme.colors.primary};
  color: white;
  border: none;
  padding: 1rem 2rem;
  border-radius: 4px;
  cursor: pointer;
  width: 100%;
  margin-top: 1rem;

  &:hover {
    background: ${props => props.theme.colors.accent};
  }
`;

function CheckoutProcess() {
  const [step, setStep] = useState(1);

  const steps = [
    { icon: <ShoppingCart />, label: 'Cart Review' },
    { icon: <Person />, label: 'Information' },
    { icon: <LocalShipping />, label: 'Shipping' },
    { icon: <Payment />, label: 'Payment' },
    { icon: <Check />, label: 'Confirmation' }
  ];

  const renderStepContent = () => {
    switch(step) {
      case 1:
        return <CartReview onNext={() => setStep(2)} />;
      case 2:
        return <CustomerInfo onNext={() => setStep(3)} />;
      case 3:
        return <ShippingInfo onNext={() => setStep(4)} />;
      case 4:
        return <PaymentInfo onNext={() => setStep(5)} />;
      case 5:
        return <OrderConfirmation />;
      default:
        return null;
    }
  };

  return (
    <CheckoutContainer>
      <Steps>
        {steps.map((s, index) => (
          <Step key={index}>
            <StepIcon active={index + 1 <= step}>
              {s.icon}
            </StepIcon>
            <StepLabel active={index + 1 <= step}>
              {s.label}
            </StepLabel>
          </Step>
        ))}
      </Steps>

      {renderStepContent()}
    </CheckoutContainer>
  );
}

// Example of one step component
function CustomerInfo({ onNext }) {
  const handleSubmit = (e) => {
    e.preventDefault();
    onNext();
  };

  return (
    <Form onSubmit={handleSubmit}>
      <FormGroup>
        <Label>Full Name</Label>
        <Input type="text" required />
      </FormGroup>

      <FormGroup>
        <Label>Email</Label>
        <Input type="email" required />
      </FormGroup>

      <FormGroup>
        <Label>Phone</Label>
        <Input type="tel" required />
      </FormGroup>

      <Button type="submit">Continue to Shipping</Button>
    </Form>
  );
}

export default CheckoutProcess; 