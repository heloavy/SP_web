import { useState } from 'react';
import styled from 'styled-components';
import {
  Assignment,
  Timer,
  CheckCircle,
  Help,
  NavigateNext,
  NavigateBefore,
  Flag,
  Save,
  Send
} from '@mui/icons-material';

const AssessmentContainer = styled.div`
  max-width: 800px;
  margin: 2rem auto;
  padding: 2rem;
`;

const QuizHeader = styled.div`
  background: white;
  padding: 1.5rem;
  border-radius: 8px;
  box-shadow: 0 2px 4px rgba(0,0,0,0.1);
  margin-bottom: 2rem;
  display: flex;
  justify-content: space-between;
  align-items: center;
`;

const TimerDisplay = styled.div`
  display: flex;
  align-items: center;
  gap: 0.5rem;
  padding: 0.5rem 1rem;
  background: ${props => props.timeWarning ? '#fff3e0' : props.theme.colors.grey};
  border-radius: 4px;
  color: ${props => props.timeWarning ? '#e65100' : props.theme.colors.text};
`;

const QuestionCard = styled.div`
  background: white;
  padding: 1.5rem;
  border-radius: 8px;
  box-shadow: 0 2px 4px rgba(0,0,0,0.1);
  margin-bottom: 1rem;
`;

const OptionList = styled.div`
  display: flex;
  flex-direction: column;
  gap: 1rem;
  margin: 1.5rem 0;
`;

const Option = styled.div`
  padding: 1rem;
  border: 2px solid ${props => props.selected ? props.theme.colors.primary : props.theme.colors.grey};
  border-radius: 8px;
  cursor: pointer;
  transition: all 0.3s ease;

  &:hover {
    background: ${props => props.theme.colors.grey};
  }
`;

const NavigationBar = styled.div`
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-top: 2rem;
`;

const QuestionNav = styled.div`
  display: flex;
  gap: 0.5rem;
  flex-wrap: wrap;
`;

const QuestionDot = styled.div`
  width: 30px;
  height: 30px;
  border-radius: 50%;
  display: flex;
  align-items: center;
  justify-content: center;
  cursor: pointer;
  background: ${props => props.active ? props.theme.colors.primary : props.answered ? '#e8f5e9' : 'white'};
  color: ${props => props.active ? 'white' : props.answered ? '#2e7d32' : props.theme.colors.text};
  border: 1px solid ${props => props.active ? props.theme.colors.primary : props.theme.colors.grey};
`;

const Button = styled.button`
  display: flex;
  align-items: center;
  gap: 0.5rem;
  padding: 0.8rem 1.5rem;
  border: none;
  border-radius: 4px;
  background: ${props => props.primary ? props.theme.colors.primary : 'white'};
  color: ${props => props.primary ? 'white' : props.theme.colors.text};
  cursor: pointer;
  box-shadow: 0 2px 4px rgba(0,0,0,0.1);

  &:hover {
    background: ${props => props.primary ? props.theme.colors.accent : '#f5f5f5'};
  }

  &:disabled {
    opacity: 0.5;
    cursor: not-allowed;
  }
`;

function AssessmentSystem() {
  const [currentQuestion, setCurrentQuestion] = useState(0);
  const [answers, setAnswers] = useState({});
  const [timeLeft, setTimeLeft] = useState(3600); // 1 hour in seconds

  const questions = [
    {
      id: 1,
      question: "What is the capital of France?",
      options: ["London", "Berlin", "Paris", "Madrid"],
      correctAnswer: 2
    },
    // More questions...
  ];

  const handleAnswer = (questionId, answerIndex) => {
    setAnswers({
      ...answers,
      [questionId]: answerIndex
    });
  };

  const handleSubmit = () => {
    // Submit assessment logic
  };

  return (
    <AssessmentContainer>
      <QuizHeader>
        <div>
          <h2>Mathematics Assessment</h2>
          <p>Chapter 3: Algebra</p>
        </div>
        <TimerDisplay timeWarning={timeLeft < 300}>
          <Timer />
          {Math.floor(timeLeft / 60)}:{timeLeft % 60}
        </TimerDisplay>
      </QuizHeader>

      <QuestionCard>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
          <h3>Question {currentQuestion + 1} of {questions.length}</h3>
          <Button>
            <Flag /> Flag for Review
          </Button>
        </div>

        <p>{questions[currentQuestion].question}</p>

        <OptionList>
          {questions[currentQuestion].options.map((option, index) => (
            <Option
              key={index}
              selected={answers[questions[currentQuestion].id] === index}
              onClick={() => handleAnswer(questions[currentQuestion].id, index)}
            >
              {option}
            </Option>
          ))}
        </OptionList>

        <NavigationBar>
          <Button
            onClick={() => setCurrentQuestion(prev => prev - 1)}
            disabled={currentQuestion === 0}
          >
            <NavigateBefore /> Previous
          </Button>

          <QuestionNav>
            {questions.map((_, index) => (
              <QuestionDot
                key={index}
                active={currentQuestion === index}
                answered={answers[questions[index].id] !== undefined}
                onClick={() => setCurrentQuestion(index)}
              >
                {index + 1}
              </QuestionDot>
            ))}
          </QuestionNav>

          {currentQuestion === questions.length - 1 ? (
            <Button primary onClick={handleSubmit}>
              <Send /> Submit
            </Button>
          ) : (
            <Button
              onClick={() => setCurrentQuestion(prev => prev + 1)}
              disabled={currentQuestion === questions.length - 1}
            >
              Next <NavigateNext />
            </Button>
          )}
        </NavigationBar>
      </QuestionCard>
    </AssessmentContainer>
  );
}

export default AssessmentSystem; 