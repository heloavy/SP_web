import { useState } from 'react';
import styled from 'styled-components';
import { 
  Person, 
  Notifications, 
  Security, 
  Language,
  ColorLens
} from '@mui/icons-material';

const SettingsContainer = styled.div`
  max-width: 800px;
  margin: 0 auto;
  padding: 2rem;
`;

const SettingsGrid = styled.div`
  display: grid;
  grid-template-columns: 200px 1fr;
  gap: 2rem;

  @media (max-width: 768px) {
    grid-template-columns: 1fr;
  }
`;

const SettingsNav = styled.div`
  background: white;
  padding: 1rem;
  border-radius: 8px;
  box-shadow: 0 2px 4px rgba(0,0,0,0.1);
`;

const NavItem = styled.div`
  display: flex;
  align-items: center;
  gap: 0.5rem;
  padding: 0.8rem;
  cursor: pointer;
  border-radius: 4px;
  color: ${props => props.active ? props.theme.colors.primary : props.theme.colors.text};
  background: ${props => props.active ? props.theme.colors.primary + '10' : 'transparent'};

  &:hover {
    background: ${props => props.theme.colors.grey};
  }
`;

const SettingsPanel = styled.div`
  background: white;
  padding: 2rem;
  border-radius: 8px;
  box-shadow: 0 2px 4px rgba(0,0,0,0.1);
`;

const Form = styled.form`
  display: flex;
  flex-direction: column;
  gap: 1.5rem;
`;

const FormGroup = styled.div`
  display: flex;
  flex-direction: column;
  gap: 0.5rem;
`;

const Label = styled.label`
  font-weight: bold;
`;

const Input = styled.input`
  padding: 0.8rem;
  border: 1px solid ${props => props.theme.colors.grey};
  border-radius: 4px;

  &:focus {
    outline: none;
    border-color: ${props => props.theme.colors.primary};
  }
`;

const Switch = styled.label`
  position: relative;
  display: inline-block;
  width: 60px;
  height: 34px;

  input {
    opacity: 0;
    width: 0;
    height: 0;
  }

  span {
    position: absolute;
    cursor: pointer;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    background-color: #ccc;
    transition: .4s;
    border-radius: 34px;

    &:before {
      position: absolute;
      content: "";
      height: 26px;
      width: 26px;
      left: 4px;
      bottom: 4px;
      background-color: white;
      transition: .4s;
      border-radius: 50%;
    }
  }

  input:checked + span {
    background-color: ${props => props.theme.colors.primary};
  }

  input:checked + span:before {
    transform: translateX(26px);
  }
`;

const Button = styled.button`
  background: ${props => props.theme.colors.primary};
  color: white;
  border: none;
  padding: 0.8rem;
  border-radius: 4px;
  cursor: pointer;

  &:hover {
    background: ${props => props.theme.colors.accent};
  }
`;

function UserSettings() {
  const [activeSection, setActiveSection] = useState('profile');
  const [settings, setSettings] = useState({
    notifications: true,
    emailUpdates: true,
    darkMode: false,
    language: 'en'
  });

  const renderSettingsContent = () => {
    switch(activeSection) {
      case 'profile':
        return <ProfileSettings />;
      case 'notifications':
        return <NotificationSettings settings={settings} setSettings={setSettings} />;
      case 'security':
        return <SecuritySettings />;
      default:
        return <ProfileSettings />;
    }
  };

  return (
    <SettingsContainer>
      <h2>Account Settings</h2>
      <SettingsGrid>
        <SettingsNav>
          <NavItem 
            active={activeSection === 'profile'}
            onClick={() => setActiveSection('profile')}
          >
            <Person /> Profile
          </NavItem>
          <NavItem 
            active={activeSection === 'notifications'}
            onClick={() => setActiveSection('notifications')}
          >
            <Notifications /> Notifications
          </NavItem>
          <NavItem 
            active={activeSection === 'security'}
            onClick={() => setActiveSection('security')}
          >
            <Security /> Security
          </NavItem>
        </SettingsNav>

        <SettingsPanel>
          {renderSettingsContent()}
        </SettingsPanel>
      </SettingsGrid>
    </SettingsContainer>
  );
}

// Example of one settings section
function NotificationSettings({ settings, setSettings }) {
  return (
    <Form>
      <h3>Notification Preferences</h3>
      
      <FormGroup>
        <Label>Push Notifications</Label>
        <Switch>
          <input
            type="checkbox"
            checked={settings.notifications}
            onChange={(e) => setSettings({...settings, notifications: e.target.checked})}
          />
          <span></span>
        </Switch>
      </FormGroup>

      <FormGroup>
        <Label>Email Updates</Label>
        <Switch>
          <input
            type="checkbox"
            checked={settings.emailUpdates}
            onChange={(e) => setSettings({...settings, emailUpdates: e.target.checked})}
          />
          <span></span>
        </Switch>
      </FormGroup>

      <Button type="submit">Save Changes</Button>
    </Form>
  );
}

export default UserSettings; 