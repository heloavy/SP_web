import { useState } from 'react';
import {
  Person,
  School,
  Assessment,
  Event,
  Message,
  Payment,
  Notifications,
  TrendingUp,
  AttachMoney
} from '@mui/icons-material';
import './ParentPortal.css';

function ParentPortal() {
  const [selectedStudent, setSelectedStudent] = useState('1');
  const [students] = useState([
    { id: '1', name: 'John Doe', grade: '6th Grade' },
    { id: '2', name: 'Jane Doe', grade: '4th Grade' }
  ]);

  return (
    <div className="portal-container">
      <div className="student-selector">
        <div className="student-avatar">
          <Person />
        </div>
        <div>
          <select 
            className="select"
            value={selectedStudent}
            onChange={(e) => setSelectedStudent(e.target.value)}
          >
            {students.map(student => (
              <option key={student.id} value={student.id}>
                {student.name} - {student.grade}
              </option>
            ))}
          </select>
        </div>
      </div>

      <div className="dashboard-grid">
        <div className="card">
          <h3><Assessment /> Academic Progress</h3>
          <div>
            <div style={{ display: 'flex', justifyContent: 'space-between' }}>
              <span>Mathematics</span>
              <span>85%</span>
            </div>
            <div className="progress-bar">
              <div className="progress" style={{ width: '85%', backgroundColor: '#2196f3' }}></div>
            </div>

            <div style={{ display: 'flex', justifyContent: 'space-between' }}>
              <span>Science</span>
              <span>78%</span>
            </div>
            <div className="progress-bar">
              <div className="progress" style={{ width: '78%', backgroundColor: '#4caf50' }}></div>
            </div>

            <div style={{ display: 'flex', justifyContent: 'space-between' }}>
              <span>English</span>
              <span>92%</span>
            </div>
            <div className="progress-bar">
              <div className="progress" style={{ width: '92%', backgroundColor: '#ff9800' }}></div>
            </div>
          </div>
        </div>

        <div className="card">
          <h3><School /> Recent Grades</h3>
          <table className="grade-table">
            <thead>
              <tr>
                <th>Subject</th>
                <th>Assignment</th>
                <th>Grade</th>
              </tr>
            </thead>
            <tbody>
              <tr>
                <td>Mathematics</td>
                <td>Quiz 3</td>
                <td>90%</td>
              </tr>
              <tr>
                <td>Science</td>
                <td>Lab Report</td>
                <td>85%</td>
              </tr>
              <tr>
                <td>English</td>
                <td>Essay</td>
                <td>88%</td>
              </tr>
            </tbody>
          </table>
        </div>

        <div className="card">
          <h3><Event /> Attendance</h3>
          <div className="attendance-grid">
            {Array.from({ length: 28 }, (_, i) => (
              <div 
                key={i}
                className={`attendance-day ${
                  Math.random() > 0.1 ? 'present' : 
                  Math.random() < 0.1 ? 'absent' : ''
                }`}
              >
                {i + 1}
              </div>
            ))}
          </div>
        </div>

        <div className="card">
          <h3><AttachMoney /> Payment History</h3>
          <div className="payment-history">
            <div className="payment-item">
              <div>
                <strong>Tuition Fee</strong>
                <div>March 2024</div>
              </div>
              <div className="payment-amount">$500</div>
            </div>
            <div className="payment-item">
              <div>
                <strong>Books & Materials</strong>
                <div>February 2024</div>
              </div>
              <div className="payment-amount">$150</div>
            </div>
            <div className="payment-item">
              <div>
                <strong>Activity Fee</strong>
                <div>February 2024</div>
              </div>
              <div className="payment-amount">$75</div>
            </div>
          </div>
        </div>

        <div className="card">
          <h3><Notifications /> Upcoming Events</h3>
          <div className="empty-state">
            No upcoming events
          </div>
        </div>

        <div className="card">
          <h3><Message /> Messages</h3>
          <div className="empty-state">
            No new messages
          </div>
        </div>
      </div>
    </div>
  );
}

export default ParentPortal; 