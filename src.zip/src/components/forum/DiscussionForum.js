import { useState } from 'react';
import styled from 'styled-components';
import {
  Comment,
  ThumbUp,
  ThumbDown,
  Share,
  Flag,
  Sort,
  Add,
  Search
} from '@mui/icons-material';

const ForumContainer = styled.div`
  max-width: 1200px;
  margin: 0 auto;
  padding: 2rem;
`;

const TopBar = styled.div`
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 2rem;
  gap: 1rem;

  @media (max-width: 768px) {
    flex-direction: column;
  }
`;

const SearchBox = styled.div`
  display: flex;
  align-items: center;
  background: white;
  border-radius: 4px;
  padding: 0.5rem 1rem;
  flex: 1;
  max-width: 400px;
  box-shadow: 0 2px 4px rgba(0,0,0,0.1);
`;

const Input = styled.input`
  border: none;
  flex: 1;
  padding: 0.5rem;
  &:focus {
    outline: none;
  }
`;

const Button = styled.button`
  display: flex;
  align-items: center;
  gap: 0.5rem;
  padding: 0.8rem 1.5rem;
  border: none;
  border-radius: 4px;
  background: ${props => props.primary ? props.theme.colors.primary : 'white'};
  color: ${props => props.primary ? 'white' : props.theme.colors.text};
  cursor: pointer;
  box-shadow: 0 2px 4px rgba(0,0,0,0.1);

  &:hover {
    background: ${props => props.primary ? props.theme.colors.accent : '#f5f5f5'};
  }
`;

const DiscussionList = styled.div`
  display: flex;
  flex-direction: column;
  gap: 1rem;
`;

const DiscussionCard = styled.div`
  background: white;
  border-radius: 8px;
  padding: 1.5rem;
  box-shadow: 0 2px 4px rgba(0,0,0,0.1);
`;

const UserInfo = styled.div`
  display: flex;
  align-items: center;
  gap: 1rem;
  margin-bottom: 1rem;
`;

const Avatar = styled.img`
  width: 40px;
  height: 40px;
  border-radius: 50%;
  object-fit: cover;
`;

const PostActions = styled.div`
  display: flex;
  align-items: center;
  gap: 1rem;
  margin-top: 1rem;
  padding-top: 1rem;
  border-top: 1px solid ${props => props.theme.colors.grey};
`;

const ActionButton = styled.button`
  display: flex;
  align-items: center;
  gap: 0.5rem;
  padding: 0.5rem;
  border: none;
  background: none;
  color: ${props => props.theme.colors.text};
  cursor: pointer;
  border-radius: 4px;

  &:hover {
    background: ${props => props.theme.colors.grey};
  }
`;

const CommentSection = styled.div`
  margin-top: 1rem;
  padding-top: 1rem;
  border-top: 1px solid ${props => props.theme.colors.grey};
`;

const Comment = styled.div`
  padding: 1rem;
  margin: 0.5rem 0;
  background: ${props => props.theme.colors.grey};
  border-radius: 4px;
`;

function DiscussionForum() {
  const [discussions, setDiscussions] = useState([
    {
      id: 1,
      user: {
        name: "John Doe",
        avatar: "/avatar1.jpg"
      },
      title: "Understanding Complex Numbers",
      content: "Can someone explain complex numbers in a simple way?",
      likes: 15,
      comments: [
        {
          id: 1,
          user: "Jane Smith",
          content: "Complex numbers are numbers that combine real and imaginary parts..."
        }
      ],
      timestamp: "2 hours ago"
    },
    // More discussions...
  ]);

  const [showNewPost, setShowNewPost] = useState(false);

  return (
    <ForumContainer>
      <TopBar>
        <SearchBox>
          <Search />
          <Input placeholder="Search discussions..." />
        </SearchBox>

        <div style={{ display: 'flex', gap: '1rem' }}>
          <Button>
            <Sort /> Sort
          </Button>
          <Button primary onClick={() => setShowNewPost(true)}>
            <Add /> New Discussion
          </Button>
        </div>
      </TopBar>

      <DiscussionList>
        {discussions.map(discussion => (
          <DiscussionCard key={discussion.id}>
            <UserInfo>
              <Avatar src={discussion.user.avatar} alt={discussion.user.name} />
              <div>
                <h4>{discussion.user.name}</h4>
                <small>{discussion.timestamp}</small>
              </div>
            </UserInfo>

            <h3>{discussion.title}</h3>
            <p>{discussion.content}</p>

            <PostActions>
              <ActionButton>
                <ThumbUp /> {discussion.likes}
              </ActionButton>
              <ActionButton>
                <Comment /> {discussion.comments.length}
              </ActionButton>
              <ActionButton>
                <Share />
              </ActionButton>
              <ActionButton>
                <Flag />
              </ActionButton>
            </PostActions>

            <CommentSection>
              {discussion.comments.map(comment => (
                <Comment key={comment.id}>
                  <strong>{comment.user}</strong>
                  <p>{comment.content}</p>
                </Comment>
              ))}
            </CommentSection>
          </DiscussionCard>
        ))}
      </DiscussionList>

      {showNewPost && (
        <Modal onClose={() => setShowNewPost(false)}>
          <h2>Create New Discussion</h2>
          {/* Add form for new discussion */}
        </Modal>
      )}
    </ForumContainer>
  );
}

export default DiscussionForum; 