import { useState } from 'react';
import styled from 'styled-components';
import { 
  PlayArrow, 
  Pause,
  SkipNext,
  VolumeUp,
  ClosedCaption,
  Fullscreen
} from '@mui/icons-material';

const LearningContainer = styled.div`
  max-width: 1200px;
  margin: 0 auto;
  padding: 2rem;
`;

const VideoPlayer = styled.div`
  background: black;
  border-radius: 8px;
  overflow: hidden;
  position: relative;
  aspect-ratio: 16/9;
`;

const Controls = styled.div`
  position: absolute;
  bottom: 0;
  left: 0;
  right: 0;
  background: linear-gradient(transparent, rgba(0,0,0,0.7));
  padding: 1rem;
  display: flex;
  align-items: center;
  gap: 1rem;
`;

const ProgressBar = styled.div`
  flex: 1;
  height: 4px;
  background: rgba(255,255,255,0.3);
  border-radius: 2px;
  cursor: pointer;
  position: relative;
`;

const Progress = styled.div`
  height: 100%;
  background: ${props => props.theme.colors.primary};
  border-radius: 2px;
  width: ${props => props.value}%;
`;

const Button = styled.button`
  background: none;
  border: none;
  color: white;
  cursor: pointer;
  padding: 0.5rem;
  border-radius: 50%;
  display: flex;
  align-items: center;
  justify-content: center;

  &:hover {
    background: rgba(255,255,255,0.1);
  }
`;

const ContentTabs = styled.div`
  display: flex;
  gap: 1rem;
  margin: 2rem 0;
  border-bottom: 1px solid ${props => props.theme.colors.grey};
`;

const Tab = styled.button`
  padding: 1rem 2rem;
  border: none;
  background: none;
  cursor: pointer;
  color: ${props => props.active ? props.theme.colors.primary : props.theme.colors.text};
  border-bottom: 2px solid ${props => props.active ? props.theme.colors.primary : 'transparent'};
`;

const Content = styled.div`
  background: white;
  padding: 2rem;
  border-radius: 8px;
  box-shadow: 0 2px 4px rgba(0,0,0,0.1);
`;

function InteractiveLearning() {
  const [isPlaying, setIsPlaying] = useState(false);
  const [progress, setProgress] = useState(0);
  const [activeTab, setActiveTab] = useState('notes');

  return (
    <LearningContainer>
      <VideoPlayer>
        <video 
          src="/sample-video.mp4"
          style={{ width: '100%', height: '100%' }}
        />
        
        <Controls>
          <Button onClick={() => setIsPlaying(!isPlaying)}>
            {isPlaying ? <Pause /> : <PlayArrow />}
          </Button>
          
          <ProgressBar onClick={(e) => {
            const rect = e.currentTarget.getBoundingClientRect();
            const percent = ((e.clientX - rect.left) / rect.width) * 100;
            setProgress(percent);
          }}>
            <Progress value={progress} />
          </ProgressBar>
          
          <Button>
            <SkipNext />
          </Button>
          
          <Button>
            <VolumeUp />
          </Button>
          
          <Button>
            <ClosedCaption />
          </Button>
          
          <Button>
            <Fullscreen />
          </Button>
        </Controls>
      </VideoPlayer>

      <ContentTabs>
        <Tab 
          active={activeTab === 'notes'}
          onClick={() => setActiveTab('notes')}
        >
          Notes
        </Tab>
        <Tab 
          active={activeTab === 'quiz'}
          onClick={() => setActiveTab('quiz')}
        >
          Quiz
        </Tab>
        <Tab 
          active={activeTab === 'resources'}
          onClick={() => setActiveTab('resources')}
        >
          Resources
        </Tab>
      </ContentTabs>

      <Content>
        {activeTab === 'notes' && (
          <div>
            <h3>Lesson Notes</h3>
            <p>Key concepts covered in this video:</p>
            {/* Add notes content */}
          </div>
        )}
        
        {activeTab === 'quiz' && (
          <div>
            <h3>Knowledge Check</h3>
            {/* Add quiz content */}
          </div>
        )}
        
        {activeTab === 'resources' && (
          <div>
            <h3>Additional Resources</h3>
            {/* Add resources content */}
          </div>
        )}
      </Content>
    </LearningContainer>
  );
}

export default InteractiveLearning; 