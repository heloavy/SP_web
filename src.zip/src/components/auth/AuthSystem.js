import { useState } from 'react';
import styled from 'styled-components';
import {
  Person,
  Lock,
  Email,
  Visibility,
  VisibilityOff,
  Google,
  Facebook,
  Apple
} from '@mui/icons-material';
import './AuthSystem.css';

const AuthContainer = styled.div`
  max-width: 400px;
  margin: 2rem auto;
  padding: 2rem;
  &.auth-container {
    /* Additional styles will be applied from CSS */
  }
`;

const AuthCard = styled.div`
  background: white;
  border-radius: 8px;
  box-shadow: 0 2px 4px rgba(0,0,0,0.1);
  padding: 2rem;
`;

const TabGroup = styled.div`
  display: flex;
  margin-bottom: 2rem;
  border-bottom: 2px solid ${props => props.theme.colors.grey};
`;

const Tab = styled.button`
  flex: 1;
  padding: 1rem;
  border: none;
  background: none;
  color: ${props => props.active ? props.theme.colors.primary : props.theme.colors.text};
  border-bottom: 2px solid ${props => props.active ? props.theme.colors.primary : 'transparent'};
  margin-bottom: -2px;
  cursor: pointer;
  font-weight: ${props => props.active ? 'bold' : 'normal'};

  &:hover {
    color: ${props => props.theme.colors.primary};
  }
`;

const Form = styled.form`
  display: flex;
  flex-direction: column;
  gap: 1.5rem;
`;

const FormGroup = styled.div`
  position: relative;
`;

const Input = styled.input`
  width: 100%;
  padding: 1rem;
  padding-left: 3rem;
  border: 1px solid ${props => props.theme.colors.grey};
  border-radius: 4px;
  font-size: 1rem;

  &:focus {
    outline: none;
    border-color: ${props => props.theme.colors.primary};
  }
`;

const InputIcon = styled.div`
  position: absolute;
  left: 1rem;
  top: 50%;
  transform: translateY(-50%);
  color: ${props => props.theme.colors.text};
`;

const PasswordToggle = styled.div`
  position: absolute;
  right: 1rem;
  top: 50%;
  transform: translateY(-50%);
  cursor: pointer;
  color: ${props => props.theme.colors.text};
`;

const Button = styled.button`
  width: 100%;
  padding: 1rem;
  border: none;
  border-radius: 4px;
  background: ${props => props.primary ? props.theme.colors.primary : 'white'};
  color: ${props => props.primary ? 'white' : props.theme.colors.text};
  font-size: 1rem;
  cursor: pointer;
  box-shadow: 0 2px 4px rgba(0,0,0,0.1);

  &:hover {
    background: ${props => props.primary ? props.theme.colors.accent : '#f5f5f5'};
  }
`;

const Divider = styled.div`
  display: flex;
  align-items: center;
  text-align: center;
  margin: 1.5rem 0;

  &::before,
  &::after {
    content: '';
    flex: 1;
    border-bottom: 1px solid ${props => props.theme.colors.grey};
  }

  span {
    padding: 0 1rem;
    color: ${props => props.theme.colors.text};
  }
`;

const SocialButtons = styled.div`
  display: flex;
  gap: 1rem;
`;

const SocialButton = styled(Button)`
  flex: 1;
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 0.5rem;
  border: 1px solid ${props => props.theme.colors.grey};
`;

function AuthSystem() {
  const [activeTab, setActiveTab] = useState('login');
  const [showPassword, setShowPassword] = useState(false);
  const [formData, setFormData] = useState({
    email: '',
    password: '',
    name: ''
  });

  const handleSubmit = (e) => {
    e.preventDefault();
    // Handle authentication
    console.log('Form submitted:', formData);
  };

  const handleChange = (e) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value
    });
  };

  return (
    <AuthContainer className="auth-container">
      <AuthCard className="auth-card">
        <TabGroup className="tab-group">
          <Tab 
            className={`tab ${activeTab === 'login' ? 'active' : ''}`}
            active={activeTab === 'login'}
            onClick={() => setActiveTab('login')}
          >
            Login
          </Tab>
          <Tab 
            className={`tab ${activeTab === 'register' ? 'active' : ''}`}
            active={activeTab === 'register'}
            onClick={() => setActiveTab('register')}
          >
            Register
          </Tab>
        </TabGroup>

        <Form onSubmit={handleSubmit} className="auth-form">
          {activeTab === 'register' && (
            <FormGroup className="form-group">
              <InputIcon className="input-icon">
                <Person />
              </InputIcon>
              <Input
                className="input"
                type="text"
                name="name"
                placeholder="Full Name"
                value={formData.name}
                onChange={handleChange}
              />
            </FormGroup>
          )}

          <FormGroup>
            <InputIcon>
              <Email />
            </InputIcon>
            <Input
              type="email"
              name="email"
              placeholder="Email Address"
              value={formData.email}
              onChange={handleChange}
            />
          </FormGroup>

          <FormGroup>
            <InputIcon>
              <Lock />
            </InputIcon>
            <Input
              type={showPassword ? 'text' : 'password'}
              name="password"
              placeholder="Password"
              value={formData.password}
              onChange={handleChange}
            />
            <PasswordToggle onClick={() => setShowPassword(!showPassword)}>
              {showPassword ? <VisibilityOff /> : <Visibility />}
            </PasswordToggle>
          </FormGroup>

          <Button primary type="submit" className="auth-button">
            {activeTab === 'login' ? 'Login' : 'Register'}
          </Button>
        </Form>

        <Divider className="divider">
          <span>or continue with</span>
        </Divider>

        <SocialButtons className="social-buttons">
          <SocialButton className="social-button">
            <Google /> Google
          </SocialButton>
          <SocialButton className="social-button">
            <Facebook /> Facebook
          </SocialButton>
          <SocialButton className="social-button">
            <Apple /> Apple
          </SocialButton>
        </SocialButtons>
      </AuthCard>
    </AuthContainer>
  );
}

export default AuthSystem; 