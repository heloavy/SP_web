import { useState } from 'react';
import styled from 'styled-components';
import {
  Grade,
  Search,
  FilterList,
  Download,
  Edit,
  Save,
  Comment,
  Send,
  CheckCircle
} from '@mui/icons-material';

const GradingContainer = styled.div`
  padding: 2rem;
`;

const Header = styled.div`
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 2rem;
`;

const SearchBar = styled.div`
  display: flex;
  align-items: center;
  gap: 1rem;
  background: white;
  padding: 0.5rem 1rem;
  border-radius: 4px;
  box-shadow: 0 2px 4px rgba(0,0,0,0.1);
  width: 300px;

  input {
    border: none;
    flex: 1;
    padding: 0.5rem;
    &:focus {
      outline: none;
    }
  }
`;

const GradingTable = styled.div`
  background: white;
  border-radius: 8px;
  box-shadow: 0 2px 4px rgba(0,0,0,0.1);
  overflow: hidden;
`;

const TableHeader = styled.div`
  display: grid;
  grid-template-columns: 2fr 1fr 1fr 1fr 1fr;
  padding: 1rem;
  background: ${props => props.theme.colors.grey};
  font-weight: bold;
`;

const TableRow = styled.div`
  display: grid;
  grid-template-columns: 2fr 1fr 1fr 1fr 1fr;
  padding: 1rem;
  border-bottom: 1px solid ${props => props.theme.colors.grey};
  align-items: center;

  &:hover {
    background: ${props => props.theme.colors.grey};
  }
`;

const GradeInput = styled.input`
  width: 60px;
  padding: 0.5rem;
  border: 1px solid ${props => props.theme.colors.grey};
  border-radius: 4px;
  text-align: center;

  &:focus {
    outline: none;
    border-color: ${props => props.theme.colors.primary};
  }
`;

const Button = styled.button`
  display: flex;
  align-items: center;
  gap: 0.5rem;
  padding: 0.8rem 1.5rem;
  border: none;
  border-radius: 4px;
  background: ${props => props.primary ? props.theme.colors.primary : 'white'};
  color: ${props => props.primary ? 'white' : props.theme.colors.text};
  cursor: pointer;
  box-shadow: 0 2px 4px rgba(0,0,0,0.1);

  &:hover {
    background: ${props => props.primary ? props.theme.colors.accent : '#f5f5f5'};
  }
`;

const CommentModal = styled.div`
  position: fixed;
  top: 50%;
  left: 50%;
  transform: translate(-50%, -50%);
  background: white;
  padding: 2rem;
  border-radius: 8px;
  box-shadow: 0 4px 8px rgba(0,0,0,0.2);
  width: 400px;
  z-index: 1000;
`;

const Overlay = styled.div`
  position: fixed;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  background: rgba(0,0,0,0.5);
  z-index: 999;
`;

const TextArea = styled.textarea`
  width: 100%;
  padding: 1rem;
  border: 1px solid ${props => props.theme.colors.grey};
  border-radius: 4px;
  resize: vertical;
  min-height: 100px;
  margin: 1rem 0;

  &:focus {
    outline: none;
    border-color: ${props => props.theme.colors.primary};
  }
`;

const GradeStatus = styled.span`
  padding: 0.3rem 0.8rem;
  border-radius: 12px;
  font-size: 0.8rem;
  background: ${props => {
    switch(props.status) {
      case 'graded': return '#e8f5e9';
      case 'pending': return '#fff3e0';
      case 'late': return '#ffebee';
      default: return '#f5f5f5';
    }
  }};
  color: ${props => {
    switch(props.status) {
      case 'graded': return '#2e7d32';
      case 'pending': return '#ef6c00';
      case 'late': return '#c62828';
      default: return '#666';
    }
  }};
`;

function GradingSystem() {
  const [submissions, setSubmissions] = useState([
    {
      id: 1,
      student: "John Doe",
      assignment: "Mathematics Quiz #3",
      submittedDate: "2024-03-15",
      status: "pending",
      grade: null,
      comment: ""
    },
    {
      id: 2,
      student: "Jane Smith",
      assignment: "Mathematics Quiz #3",
      submittedDate: "2024-03-14",
      status: "graded",
      grade: 85,
      comment: "Good work!"
    }
  ]);

  const [showCommentModal, setShowCommentModal] = useState(false);
  const [selectedSubmission, setSelectedSubmission] = useState(null);
  const [comment, setComment] = useState("");

  const handleGradeChange = (id, value) => {
    setSubmissions(submissions.map(sub =>
      sub.id === id ? { ...sub, grade: value, status: 'graded' } : sub
    ));
  };

  const openCommentModal = (submission) => {
    setSelectedSubmission(submission);
    setComment(submission.comment);
    setShowCommentModal(true);
  };

  const saveComment = () => {
    setSubmissions(submissions.map(sub =>
      sub.id === selectedSubmission.id ? { ...sub, comment } : sub
    ));
    setShowCommentModal(false);
  };

  return (
    <GradingContainer>
      <Header>
        <h2>Assignment Grading</h2>
        <div style={{ display: 'flex', gap: '1rem' }}>
          <SearchBar>
            <Search />
            <input placeholder="Search submissions..." />
          </SearchBar>
          <Button>
            <FilterList /> Filter
          </Button>
          <Button>
            <Download /> Export
          </Button>
        </div>
      </Header>

      <GradingTable>
        <TableHeader>
          <div>Student</div>
          <div>Submitted</div>
          <div>Status</div>
          <div>Grade</div>
          <div>Actions</div>
        </TableHeader>

        {submissions.map(submission => (
          <TableRow key={submission.id}>
            <div>
              <div>{submission.student}</div>
              <small>{submission.assignment}</small>
            </div>
            <div>{submission.submittedDate}</div>
            <div>
              <GradeStatus status={submission.status}>
                {submission.status}
              </GradeStatus>
            </div>
            <div>
              <GradeInput
                type="number"
                value={submission.grade || ''}
                onChange={(e) => handleGradeChange(submission.id, e.target.value)}
                min="0"
                max="100"
              />
            </div>
            <div style={{ display: 'flex', gap: '0.5rem' }}>
              <Button onClick={() => openCommentModal(submission)}>
                <Comment />
              </Button>
              <Button primary>
                <Send />
              </Button>
            </div>
          </TableRow>
        ))}
      </GradingTable>

      {showCommentModal && (
        <>
          <Overlay onClick={() => setShowCommentModal(false)} />
          <CommentModal>
            <h3>Add Comment</h3>
            <TextArea
              value={comment}
              onChange={(e) => setComment(e.target.value)}
              placeholder="Enter feedback for student..."
            />
            <div style={{ display: 'flex', justifyContent: 'flex-end', gap: '1rem' }}>
              <Button onClick={() => setShowCommentModal(false)}>
                Cancel
              </Button>
              <Button primary onClick={saveComment}>
                <Save /> Save Comment
              </Button>
            </div>
          </CommentModal>
        </>
      )}
    </GradingContainer>
  );
}

export default GradingSystem; 